# USB Screen Mirror (OBS-Style Video Composition Studio)

Aplikasi native Android berperforma tinggi untuk mirroring layar HP Client (**Realme 5 Pro**) ke HP Host (**Xiaomi 14T**) melalui kabel **USB OTG** langsung menggunakan protokol ADB over USB Host API dan akselerasi perangkat keras `MediaCodec` (H.264), dilengkapi kanvas komposisi multi-layer ala **OBS Studio**.

---

## 1. Arsitektur & Spesifikasi Perangkat

* **Host Device:** Xiaomi 14T (terpasang aplikasi USB Screen Mirror, bertindak sebagai USB Host OTG).
* **Client Device:** Realme 5 Pro (cukup aktifkan USB Debugging di Opsi Pengembang, **tanpa perlu install aplikasi tambahan apapun**).
* **Koneksi:** Kabel USB OTG (Host Type-C ke Client Micro-USB / Type-C).
* **Format Video:** H.264 stream Annex-B melalui channel `exec:screenrecord`.
* **Decoder:** Android `MediaCodec` ("video/avc") hardware-accelerated.

---

## 2. Fitur Utama

### A. Satu Activity & Satu Workspace
* Seluruh siklus aplikasi berjalan dalam satu `MainActivity` terpadu.
* Menghilangkan masalah pembukaan Activity kedua atau penumpukan antarmuka ganda.
* Transisi state mesin real-time:
  * `DISCONNECTED`
  * `USB DEVICE DETECTED`
  * `USB PERMISSION REQUIRED`
  * `ADB AUTHENTICATION`
  * `CONNECTING`
  * `CONNECTED`
  * `STREAMING` (Indikator LIVE aktif dengan FPS & Bitrate aktual)
  * `DECODER ERROR`
  * `USB DISCONNECTED`
  * `ERROR`

### B. Kanvas Komposisi Video ala OBS Studio
* **Satu Canvas Bersama:** Tempat semua sumber visual dikomposisikan.
* **Transformasi Interaktif Langsung:**
  * Bounding box seleksi dengan 4 handle sudut (Top-Left, Top-Right, Bottom-Left, Bottom-Right).
  * Tarik area layer untuk menggeser posisi (Drag to Move).
  * Tarik handle sudut untuk memperbesar/memperkecil (Corner Drag to Resize).
  * Tombol **FIT** (menyesuaikan ukuran layer ke tengah kanvas dengan rasio aspek terjaga).
  * Tombol **FILL** (memenuhi seluruh kanvas 100%).
  * Tombol **RESET** (mengembalikan layer ke konfigurasi bawaan).
  * Mengubah ukuran atau memindahkan layer **TIDAK** memutus streaming atau me-restart decoder.

### C. Sistem Layer Independen
* **Layer Mirroring USB:** Menampilkan layar Client (Realme 5 Pro).
* **Layer Kamera Host:** Menggunakan kamera depan/belakang Xiaomi 14T (CameraX) untuk facecam / overlay.
* **Kontrol Per-Layer:**
  * Visibility toggle (ikon mata): Menyembunyikan layer tanpa menghentikan decoder atau ADB.
  * Lock toggle (ikon gembok): Mengunci posisi dan ukuran agar tidak bergeser saat disentuh.
  * Z-Order (Bring Forward / Send Backward): Mengatur urutan tumpukan layer.
  * Kamera Depan/Belakang: Pergantian lensa tanpa memutus mirroring USB.
  * Penyimpanan Konfigurasi: Posisi, ukuran, visibilitas, dan urutan layer otomatis tersimpan secara persisten.

### D. Audit Kelayakan Teknis Audio Client & Host Mixer
* **Laporan Audit Teknis Kejujuran:**
  * Biner Android AOSP `/system/bin/screenrecord` hanya menangkap buffer video VirtualDisplay/SurfaceFlinger dan **TIDAK** mendukung audio internal.
  * Android membatasi audio internal melalui `AudioPlaybackCapture` API yang mewajibkan izin `MediaProjection` dan instalasi aplikasi client di Realme 5 Pro.
  * Karena arsitektur proyek ini adalah **tanpa aplikasi tambahan di Client**, audio internal Realme 5 Pro tidak dapat ditarik hanya dari perintah screenrecord ADB.
* **Solusi Nyata yang Disediakan:**
  * **Host Microphone Mixer:** Pengambilan suara mikrofon Xiaomi 14T untuk voiceover/komentari live streaming dengan tombol Mute/Unmute dan Slider Volume (0-100%).
  * Untuk audio game/sistem Client, disarankan menghubungkan kabel audio 3.5mm aux langsung dari Realme 5 Pro ke input/adapter Host.

---

## 3. Panduan Kompilasi & Build APK

Untuk mengompilasi APK debug:
```bash
gradle assembleDebug
```
Lokasi file APK hasil kompilasi:
`app/build/outputs/apk/debug/app-debug.apk`

Untuk menjalankan pengujian unit dan Robolectric:
```bash
gradle :app:testDebugUnitTest
```

---

## 4. Panduan Pengujian pada Perangkat Fisik

1. **Persiapan Client (Realme 5 Pro):**
   * Buka **Pengaturan** -> **Tentang Ponsel** -> Ketuk **Nomor Bentukan (Build Number)** sebanyak 7 kali hingga Mode Pengembang aktif.
   * Masuk ke **Pengaturan Tambahan** -> **Opsi Pengembang**.
   * Aktifkan **USB Debugging** (Debugging USB).

2. **Koneksi Fisik:**
   * Pasang adapter USB OTG pada HP Host (Xiaomi 14T).
   * Sambungkan kabel data dari adapter OTG Xiaomi 14T ke port Realme 5 Pro.

3. **Operasi Aplikasi (Xiaomi 14T):**
   * Buka aplikasi **USB Screen Mirror**.
   * Tekan tombol **CONNECT**.
   * Dialog sistem Android akan meminta izin akses perangkat USB Host -> Pilih **OK/Izinkan**.
   * Di layar Realme 5 Pro akan muncul dialog otorisasi ADB: *"Izinkan debugging USB? Kunci sidik jari RSA komputer: ..."* -> Centang **"Selalu izinkan dari komputer ini"** lalu ketuk **OK**.
   * Aplikasi akan otomatis beralih ke state **CONNECTED** lalu **STREAMING**.
   * Indikator **LIVE** merah akan menyala dengan FPS aktual (~30-60 fps) dan bitrate real-time (~4 Mbps).
   * Geser, ubah ukuran, atau atur posisi kamera host dan mirroring di kanvas sesuai kebutuhan Anda.
