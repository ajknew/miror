package com.usbscreenmirror

import com.usbscreenmirror.adb.AdbProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AdbProtocolTest {

    @Test
    fun testChecksumCalculation() {
        val payload = "host::UsbScreenMirror".toByteArray(Charsets.UTF_8)
        val checksum = AdbProtocol.calculateChecksum(payload)
        assertTrue(checksum > 0)
    }

    @Test
    fun testMessageSerializationAndHeaderParsing() {
        val message = AdbProtocol.createConnectMessage("host::UsbScreenMirror")
        val serialized = message.serialize()

        assertEquals(24 + message.payload.size, serialized.size)

        val header = AdbProtocol.parseHeader(serialized)
        assertEquals(AdbProtocol.CMD_CNXN, header.command)
        assertEquals(AdbProtocol.ADB_VERSION, header.arg0)
        assertEquals(AdbProtocol.MAX_DATA, header.arg1)
        assertEquals(message.payload.size, header.dataLength)
        assertTrue(header.isValid)
    }

    @Test
    fun testOpenMessageCreation() {
        val cmd = "exec:screenrecord --output-format=h264 -"
        val openMsg = AdbProtocol.createOpenMessage(1, cmd)
        assertEquals(AdbProtocol.CMD_OPEN, openMsg.command)
        assertEquals(1, openMsg.arg0)
        assertEquals(0, openMsg.arg1)
        assertTrue(openMsg.payload.isNotEmpty())

        val serialized = openMsg.serialize()
        val parsedHeader = AdbProtocol.parseHeader(serialized)
        assertTrue(parsedHeader.isValid)
        assertEquals(AdbProtocol.CMD_OPEN, parsedHeader.command)
    }

    @Test
    fun testOkayMessageCreation() {
        val okayMsg = AdbProtocol.createOkayMessage(1, 2)
        assertEquals(AdbProtocol.CMD_OKAY, okayMsg.command)
        assertEquals(1, okayMsg.arg0)
        assertEquals(2, okayMsg.arg1)
        assertEquals(0, okayMsg.payload.size)

        val serialized = okayMsg.serialize()
        assertEquals(24, serialized.size)
        val parsedHeader = AdbProtocol.parseHeader(serialized)
        assertTrue(parsedHeader.isValid)
    }
}
