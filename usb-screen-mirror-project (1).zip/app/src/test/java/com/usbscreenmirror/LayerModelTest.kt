package com.usbscreenmirror

import com.usbscreenmirror.model.LayerType
import com.usbscreenmirror.model.StudioLayer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LayerModelTest {

    @Test
    fun testLayerJsonSerialization() {
        val original = StudioLayer(
            id = "test_layer_1",
            name = "Test Mirror",
            type = LayerType.USB_MIRROR,
            isVisible = true,
            isLocked = false,
            x = 0.1f,
            y = 0.2f,
            width = 0.8f,
            height = 0.6f,
            zIndex = 2,
            keepAspectRatio = true,
            sourceAspect = 16f / 9f
        )

        val json = original.toJson()
        val restored = StudioLayer.fromJson(json)

        assertEquals(original.id, restored.id)
        assertEquals(original.name, restored.name)
        assertEquals(original.type, restored.type)
        assertEquals(original.isVisible, restored.isVisible)
        assertEquals(original.isLocked, restored.isLocked)
        assertEquals(original.x, restored.x, 0.001f)
        assertEquals(original.y, restored.y, 0.001f)
        assertEquals(original.width, restored.width, 0.001f)
        assertEquals(original.height, restored.height, 0.001f)
        assertEquals(original.zIndex, restored.zIndex)
        assertEquals(original.keepAspectRatio, restored.keepAspectRatio)
    }

    @Test
    fun testLockAndVisibilityIndependence() {
        val layer1 = StudioLayer(
            id = "layer_1",
            name = "Layer 1",
            type = LayerType.USB_MIRROR,
            isVisible = true,
            isLocked = false
        )
        val layer2 = StudioLayer(
            id = "layer_2",
            name = "Layer 2",
            type = LayerType.HOST_CAMERA,
            isVisible = false,
            isLocked = true
        )

        assertTrue(layer1.isVisible)
        assertFalse(layer1.isLocked)
        assertFalse(layer2.isVisible)
        assertTrue(layer2.isLocked)
    }
}
