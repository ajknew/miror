package com.usbscreenmirror.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbscreenmirror.model.DiagnosticLog
import com.usbscreenmirror.model.LogLevel
import com.usbscreenmirror.model.StreamingMetrics
import com.usbscreenmirror.ui.theme.StudioAccent
import com.usbscreenmirror.ui.theme.StudioLiveRed
import com.usbscreenmirror.ui.theme.StudioSuccess
import com.usbscreenmirror.ui.theme.StudioSurface
import com.usbscreenmirror.ui.theme.StudioSurfaceVariant
import com.usbscreenmirror.ui.theme.StudioTextMuted
import com.usbscreenmirror.ui.theme.StudioTextPrimary
import com.usbscreenmirror.ui.theme.StudioWarning
import com.usbscreenmirror.viewmodel.StudioViewModel

@Composable
fun DiagnosticsPanel(
    viewModel: StudioViewModel,
    metrics: StreamingMetrics,
    logs: List<DiagnosticLog>,
    selectedResolution: String,
    selectedBitrate: Int,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto scroll to bottom when new logs arrive
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
            .testTag("diagnostics_panel")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, contentDescription = "Metrics", tint = StudioAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "STREAMING METRICS & ADB LOGS",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = StudioTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Resolution & Bitrate Selectors
            Text(
                text = "Target Resolusi Streaming Client:",
                fontSize = 11.sp,
                color = StudioTextMuted
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("1280x720", "1920x1080", "960x540").forEach { res ->
                    FilterChip(
                        selected = selectedResolution == res,
                        onClick = { viewModel.setResolution(res) },
                        label = { Text(res, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioAccent,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Target Bitrate:",
                fontSize = 11.sp,
                color = StudioTextMuted
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("2 Mbps" to 2_000_000, "4 Mbps" to 4_000_000, "6 Mbps" to 6_000_000).forEach { (label, rate) ->
                    FilterChip(
                        selected = selectedBitrate == rate,
                        onClick = { viewModel.setBitrate(rate) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioAccent,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live Telemetry Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TelemetryCard(
                    title = "ACTUAL FPS",
                    value = "${metrics.fps.toInt()} fps",
                    subtext = "Decoded output",
                    accentColor = StudioSuccess,
                    modifier = Modifier.weight(1f)
                )
                TelemetryCard(
                    title = "ACTUAL BITRATE",
                    value = "${(metrics.bitrateKbps / 1000f).let { "%.1f".format(it) }} Mbps",
                    subtext = "Received bytes",
                    accentColor = StudioAccent,
                    modifier = Modifier.weight(1f)
                )
                TelemetryCard(
                    title = "FRAMES",
                    value = "${metrics.totalFramesDecoded}",
                    subtext = "MediaCodec HW",
                    accentColor = StudioTextPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Diagnostic Console Terminal
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BugReport, contentDescription = "Terminal", tint = StudioAccent, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "ADB & Decoder Console (${logs.size} log)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = 160.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF07080B))
                    .padding(6.dp)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(logs) { log ->
                        val color = when (log.level) {
                            LogLevel.INFO -> StudioTextMuted
                            LogLevel.WARN -> StudioWarning
                            LogLevel.ERROR -> StudioLiveRed
                            LogLevel.SUCCESS -> StudioSuccess
                        }
                        Text(
                            text = "[${log.formattedTime}] [${log.tag}] ${log.message}",
                            color = color,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryCard(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(StudioSurfaceVariant)
            .padding(8.dp)
    ) {
        Column {
            Text(title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioTextMuted)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Text(subtext, fontSize = 9.sp, color = StudioTextMuted)
        }
    }
}
