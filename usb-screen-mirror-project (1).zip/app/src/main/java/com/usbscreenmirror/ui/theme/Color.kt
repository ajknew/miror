package com.usbscreenmirror.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDarkBg = Color(0xFF0C0D11)
val StudioSurface = Color(0xFF14161E)
val StudioSurfaceVariant = Color(0xFF1E212B)
val StudioCanvasBg = Color(0xFF050608)

val StudioAccent = Color(0xFF06B6D4) // Cyan accent
val StudioAccentHover = Color(0xFF22D3EE)
val StudioSuccess = Color(0xFF10B981) // Emerald green
val StudioLiveRed = Color(0xFFEF4444) // Live broadcast red
val StudioWarning = Color(0xFFF59E0B) // Amber warning

val StudioTextPrimary = Color(0xFFF9FAFB)
val StudioTextSecondary = Color(0xFF9CA3AF)
val StudioTextMuted = Color(0xFF6B7280)
val StudioBorder = Color(0xFF2A2E3B)
val StudioSelectionHandle = Color(0xFF38BDF8)
