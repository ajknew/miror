package com.usbscreenmirror.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbscreenmirror.camera.CameraLens
import com.usbscreenmirror.model.LayerType
import com.usbscreenmirror.model.StudioLayer
import com.usbscreenmirror.ui.theme.StudioAccent
import com.usbscreenmirror.ui.theme.StudioBorder
import com.usbscreenmirror.ui.theme.StudioSurface
import com.usbscreenmirror.ui.theme.StudioSurfaceVariant
import com.usbscreenmirror.ui.theme.StudioTextMuted
import com.usbscreenmirror.ui.theme.StudioTextPrimary
import com.usbscreenmirror.ui.theme.StudioTextSecondary
import com.usbscreenmirror.viewmodel.StudioViewModel

@Composable
fun LayersPanel(
    viewModel: StudioViewModel,
    layers: List<StudioLayer>,
    selectedLayerId: String?,
    currentLens: CameraLens,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
            .testTag("layers_panel")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "OBS LAYERS",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = StudioTextPrimary
                )
                Text(
                    text = "${layers.size} Sumber Aktif",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Layers List
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Display in reverse visual order (top of list = topmost zIndex)
                val displayList = layers.sortedByDescending { it.zIndex }
                for (layer in displayList) {
                    val isSelected = layer.id == selectedLayerId

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) StudioSurfaceVariant else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) StudioAccent else StudioBorder,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.selectLayer(layer.id) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Visibility toggle
                        IconButton(
                            onClick = { viewModel.toggleLayerVisibility(layer.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (layer.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = if (layer.isVisible) "Hide layer" else "Show layer",
                                tint = if (layer.isVisible) StudioTextPrimary else StudioTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Lock toggle
                        IconButton(
                            onClick = { viewModel.toggleLayerLock(layer.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (layer.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = if (layer.isLocked) "Unlock layer" else "Lock layer",
                                tint = if (layer.isLocked) StudioAccent else StudioTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Type Icon
                        Icon(
                            imageVector = when (layer.type) {
                                LayerType.USB_MIRROR -> Icons.Default.Tv
                                LayerType.HOST_CAMERA -> Icons.Default.Videocam
                            },
                            contentDescription = layer.name,
                            tint = StudioAccent,
                            modifier = Modifier.size(18.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Layer Name
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = layer.name,
                                color = StudioTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = "Z: ${layer.zIndex} • (${(layer.width * 100).toInt()}% × ${(layer.height * 100).toInt()}%)",
                                color = StudioTextMuted,
                                fontSize = 10.sp
                            )
                        }

                        // Reorder buttons (Move Up / Move Down)
                        IconButton(
                            onClick = { viewModel.bringLayerForward(layer.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.ArrowUpward,
                                contentDescription = "Bring forward",
                                tint = StudioTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        IconButton(
                            onClick = { viewModel.sendLayerBackward(layer.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.ArrowDownward,
                                contentDescription = "Send backward",
                                tint = StudioTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Transform Action Bar for Selected Layer
            val activeLayer = layers.find { it.id == selectedLayerId }
            if (activeLayer != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { viewModel.fitLayer(activeLayer.id) },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.FitScreen, contentDescription = "Fit", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FIT", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.fillLayer(activeLayer.id) },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.Fullscreen, contentDescription = "Fill", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FILL", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.resetLayer(activeLayer.id) },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RESET", fontSize = 11.sp)
                    }

                    // Special button for Host Camera: Switch Front/Back
                    if (activeLayer.type == LayerType.HOST_CAMERA) {
                        Button(
                            onClick = { viewModel.switchHostCamera() },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioAccent),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                        ) {
                            Icon(Icons.Default.Cameraswitch, contentDescription = "Switch Camera", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(currentLens.name, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
