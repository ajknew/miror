package com.usbscreenmirror.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import com.usbscreenmirror.ui.components.AudioPanel
import com.usbscreenmirror.ui.components.DiagnosticsPanel
import com.usbscreenmirror.ui.components.LayersPanel
import com.usbscreenmirror.ui.components.StudioCanvas
import com.usbscreenmirror.ui.components.StudioHeader
import com.usbscreenmirror.ui.theme.StudioDarkBg
import com.usbscreenmirror.viewmodel.StudioViewModel

@Composable
fun WorkspaceScreen(
    viewModel: StudioViewModel,
    modifier: Modifier = Modifier
) {
    val connectionState by viewModel.connectionState.collectAsState()
    val metrics by viewModel.metrics.collectAsState()
    val layers by viewModel.layers.collectAsState()
    val selectedLayerId by viewModel.selectedLayerId.collectAsState()
    val audioState by viewModel.audioState.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val currentLens by viewModel.currentCameraLens.collectAsState()
    val selectedResolution by viewModel.selectedResolution.collectAsState()
    val selectedBitrate by viewModel.selectedBitrate.collectAsState()

    var activeTab by remember { mutableStateOf("layers") }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Universal Studio Header
        StudioHeader(
            connectionState = connectionState,
            metrics = metrics,
            activeTab = activeTab,
            onTabSelected = { activeTab = it },
            onConnectClick = { viewModel.connectUsb() },
            onDisconnectClick = { viewModel.disconnectUsb() }
        )

        if (isLandscape) {
            // Landscape: Side-by-side layout
            Row(modifier = Modifier.fillMaxSize()) {
                // Left: Canvas
                Box(
                    modifier = Modifier
                        .weight(0.65f)
                        .fillMaxHeight()
                ) {
                    StudioCanvas(
                        viewModel = viewModel,
                        layers = layers,
                        selectedLayerId = selectedLayerId,
                        connectionState = connectionState
                    )
                }

                // Right: Controls
                Box(
                    modifier = Modifier
                        .weight(0.35f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                ) {
                    when (activeTab) {
                        "layers" -> LayersPanel(
                            viewModel = viewModel,
                            layers = layers,
                            selectedLayerId = selectedLayerId,
                            currentLens = currentLens
                        )
                        "audio" -> AudioPanel(
                            viewModel = viewModel,
                            audioState = audioState
                        )
                        "logs" -> DiagnosticsPanel(
                            viewModel = viewModel,
                            metrics = metrics,
                            logs = logs,
                            selectedResolution = selectedResolution,
                            selectedBitrate = selectedBitrate
                        )
                    }
                }
            }
        } else {
            // Portrait: Stacked layout
            Column(modifier = Modifier.fillMaxSize()) {
                // Top: Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.52f)
                ) {
                    StudioCanvas(
                        viewModel = viewModel,
                        layers = layers,
                        selectedLayerId = selectedLayerId,
                        connectionState = connectionState
                    )
                }

                // Bottom: Controls Panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.48f)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (activeTab) {
                        "layers" -> LayersPanel(
                            viewModel = viewModel,
                            layers = layers,
                            selectedLayerId = selectedLayerId,
                            currentLens = currentLens
                        )
                        "audio" -> AudioPanel(
                            viewModel = viewModel,
                            audioState = audioState
                        )
                        "logs" -> DiagnosticsPanel(
                            viewModel = viewModel,
                            metrics = metrics,
                            logs = logs,
                            selectedResolution = selectedResolution,
                            selectedBitrate = selectedBitrate
                        )
                    }
                }
            }
        }
    }
}
