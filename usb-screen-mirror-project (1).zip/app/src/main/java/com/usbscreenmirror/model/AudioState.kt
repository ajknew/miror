package com.usbscreenmirror.model

data class AudioState(
    val hostMicMuted: Boolean = false,
    val hostMicVolume: Float = 1.0f,
    val isRecordingHostAudio: Boolean = false,
    val clientAudioTechnicalStatus: String = "Client Audio via ADB raw stream: Not supported by AOSP screenrecord without client agent.",
    val isClientAudioSupportedDirectly: Boolean = false
)
