package com.usbscreenmirror.model

sealed class ConnectionState(val title: String) {
    data object Disconnected : ConnectionState("DISCONNECTED")
    data class DeviceDetected(
        val deviceName: String,
        val vendorId: Int,
        val productId: Int
    ) : ConnectionState("USB DEVICE DETECTED")
    data object PermissionRequired : ConnectionState("USB PERMISSION REQUIRED")
    data class AdbAuthentication(val message: String) : ConnectionState("ADB AUTHENTICATION")
    data object Connecting : ConnectionState("CONNECTING")
    data class Connected(val deviceModel: String) : ConnectionState("CONNECTED")
    data class Streaming(val resolution: String) : ConnectionState("STREAMING")
    data class DecoderError(val error: String) : ConnectionState("DECODER ERROR")
    data object UsbDisconnected : ConnectionState("USB DISCONNECTED")
    data class Error(val message: String) : ConnectionState("ERROR")
}
