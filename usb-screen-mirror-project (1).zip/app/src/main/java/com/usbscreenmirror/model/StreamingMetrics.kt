package com.usbscreenmirror.model

data class StreamingMetrics(
    val fps: Float = 0f,
    val bitrateKbps: Long = 0L,
    val totalFramesDecoded: Long = 0L,
    val totalBytesReceived: Long = 0L,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val isHardwareAccelerated: Boolean = true
)
