package com.usbscreenmirror.model

import org.json.JSONObject

enum class LayerType {
    USB_MIRROR,
    HOST_CAMERA
}

data class StudioLayer(
    val id: String,
    val name: String,
    val type: LayerType,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val x: Float = 0f,
    val y: Float = 0f,
    val width: Float = 1f,
    val height: Float = 1f,
    val zIndex: Int = 0,
    val keepAspectRatio: Boolean = true,
    val sourceAspect: Float = 16f / 9f
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("type", type.name)
            put("isVisible", isVisible)
            put("isLocked", isLocked)
            put("x", x.toDouble())
            put("y", y.toDouble())
            put("width", width.toDouble())
            put("height", height.toDouble())
            put("zIndex", zIndex)
            put("keepAspectRatio", keepAspectRatio)
            put("sourceAspect", sourceAspect.toDouble())
        }
    }

    companion object {
        fun fromJson(json: JSONObject): StudioLayer {
            return StudioLayer(
                id = json.getString("id"),
                name = json.getString("name"),
                type = LayerType.valueOf(json.getString("type")),
                isVisible = json.optBoolean("isVisible", true),
                isLocked = json.optBoolean("isLocked", false),
                x = json.optDouble("x", 0.0).toFloat(),
                y = json.optDouble("y", 0.0).toFloat(),
                width = json.optDouble("width", 1.0).toFloat(),
                height = json.optDouble("height", 1.0).toFloat(),
                zIndex = json.optInt("zIndex", 0),
                keepAspectRatio = json.optBoolean("keepAspectRatio", true),
                sourceAspect = json.optDouble("sourceAspect", 16.0 / 9.0).toFloat()
            )
        }
    }
}
