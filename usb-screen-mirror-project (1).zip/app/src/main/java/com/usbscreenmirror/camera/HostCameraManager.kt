package com.usbscreenmirror.camera

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.usbscreenmirror.model.LogLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CameraLens {
    FRONT,
    BACK
}

class HostCameraManager(
    private val context: Context,
    private val onLog: (String, String, LogLevel) -> Unit
) {
    companion object {
        private const val TAG = "HostCameraManager"
    }

    private var cameraProvider: ProcessCameraProvider? = null
    private var previewUseCase: Preview? = null
    private var currentPreviewView: PreviewView? = null
    private var currentLifecycleOwner: LifecycleOwner? = null

    private val _currentLens = MutableStateFlow(CameraLens.FRONT)
    val currentLens: StateFlow<CameraLens> = _currentLens.asStateFlow()

    private val _isCameraActive = MutableStateFlow(false)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    fun bindToPreviewView(previewView: PreviewView, lifecycleOwner: LifecycleOwner) {
        currentPreviewView = previewView
        currentLifecycleOwner = lifecycleOwner

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                bindCameraUseCases()
            } catch (e: Exception) {
                onLog(TAG, "Failed to get CameraProvider: ${e.message}", LogLevel.ERROR)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun switchCamera() {
        val newLens = if (_currentLens.value == CameraLens.FRONT) CameraLens.BACK else CameraLens.FRONT
        _currentLens.value = newLens
        onLog(TAG, "Switched Host Camera to $newLens", LogLevel.INFO)
        bindCameraUseCases()
    }

    private fun bindCameraUseCases() {
        val provider = cameraProvider ?: return
        val previewView = currentPreviewView ?: return
        val lifecycleOwner = currentLifecycleOwner ?: return

        try {
            provider.unbindAll()

            val selector = if (_currentLens.value == CameraLens.FRONT) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }
            previewUseCase = preview

            provider.bindToLifecycle(lifecycleOwner, selector, preview)
            _isCameraActive.value = true
            onLog(TAG, "Host Camera bound successfully (${_currentLens.value})", LogLevel.SUCCESS)
        } catch (e: Exception) {
            _isCameraActive.value = false
            onLog(TAG, "Error binding CameraX use case: ${e.message}", LogLevel.ERROR)
        }
    }

    fun stopCamera() {
        try {
            cameraProvider?.unbindAll()
            _isCameraActive.value = false
        } catch (_: Exception) {}
    }
}
