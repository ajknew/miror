package com.usbscreenmirror.adb

import android.content.Context
import android.util.Base64
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

class AdbKeyPair private constructor(
    val privateKey: PrivateKey,
    val publicKey: RSAPublicKey
) {
    /**
     * Signs the 20-byte challenge token received in ADB AUTH message
     */
    fun signToken(token: ByteArray): ByteArray {
        val signature = Signature.getInstance("SHA1withRSA")
        signature.initSign(privateKey)
        signature.update(token)
        return signature.sign()
    }

    /**
     * Converts the RSA public key to the standard ADB RSAPublicKey format:
     * Base64(struct RSAPublicKey) + " " + user@host + "\0"
     */
    val adbPublicKeyPayload: ByteArray by lazy {
        val structBytes = generateAdbPublicKeyStruct(publicKey)
        val base64Key = Base64.encodeToString(structBytes, Base64.NO_WRAP)
        val fullString = "$base64Key usbscreenmirror@host\u0000"
        fullString.toByteArray(Charsets.UTF_8)
    }

    companion object {
        private const val PREFS_NAME = "usbscreenmirror_adb_keys"
        private const val KEY_PRIVATE = "priv_key"
        private const val KEY_PUBLIC = "pub_key"
        private const val KEY_SIZE = 2048
        private const val KEY_WORDS = 64 // 2048 / 32

        fun getOrCreate(context: Context): AdbKeyPair {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val privBase64 = prefs.getString(KEY_PRIVATE, null)
            val pubBase64 = prefs.getString(KEY_PUBLIC, null)

            if (privBase64 != null && pubBase64 != null) {
                try {
                    val keyFactory = KeyFactory.getInstance("RSA")
                    val privBytes = Base64.decode(privBase64, Base64.DEFAULT)
                    val pubBytes = Base64.decode(pubBase64, Base64.DEFAULT)
                    val privKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(privBytes))
                    val pubKey = keyFactory.generatePublic(X509EncodedKeySpec(pubBytes)) as RSAPublicKey
                    return AdbKeyPair(privKey, pubKey)
                } catch (_: Exception) {
                    // Fallback to regeneration
                }
            }

            val generator = KeyPairGenerator.getInstance("RSA")
            generator.initialize(KEY_SIZE)
            val pair: KeyPair = generator.generateKeyPair()
            val privKey = pair.private
            val pubKey = pair.public as RSAPublicKey

            prefs.edit()
                .putString(KEY_PRIVATE, Base64.encodeToString(privKey.encoded, Base64.DEFAULT))
                .putString(KEY_PUBLIC, Base64.encodeToString(pubKey.encoded, Base64.DEFAULT))
                .apply()

            return AdbKeyPair(privKey, pubKey)
        }

        private fun generateAdbPublicKeyStruct(publicKey: RSAPublicKey): ByteArray {
            val n = publicKey.modulus
            val r32 = BigInteger.valueOf(2).pow(32)
            val r = BigInteger.valueOf(2).pow(KEY_SIZE)
            val rr = r.multiply(r).remainder(n)

            // n0inv = -1 / n[0] mod 2^32
            val n0 = n.remainder(r32)
            val n0inv = n0.modInverse(r32).negate().remainder(r32)

            val buffer = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putInt(KEY_WORDS)
            buffer.putInt(n0inv.toInt())

            // Modulus as 64 32-bit words little-endian
            putBigIntAsWords(buffer, n, KEY_WORDS)

            // R^2 mod N as 64 32-bit words little-endian
            putBigIntAsWords(buffer, rr, KEY_WORDS)

            // Exponent (usually 65537)
            buffer.putInt(publicKey.publicExponent.toInt())

            return buffer.array()
        }

        private fun putBigIntAsWords(buffer: ByteBuffer, bigInt: BigInteger, wordCount: Int) {
            val r32 = BigInteger.valueOf(2).pow(32)
            var temp = bigInt
            for (i in 0 until wordCount) {
                val word = temp.remainder(r32).toLong()
                buffer.putInt(word.toInt())
                temp = temp.divide(r32)
            }
        }
    }
}
