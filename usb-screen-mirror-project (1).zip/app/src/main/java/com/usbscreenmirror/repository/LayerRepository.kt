package com.usbscreenmirror.repository

import android.content.Context
import com.usbscreenmirror.model.LayerType
import com.usbscreenmirror.model.StudioLayer
import org.json.JSONArray

class LayerRepository(context: Context) {
    companion object {
        private const val PREFS_NAME = "usbscreenmirror_layers"
        private const val KEY_LAYERS = "studio_layers_json"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getDefaultLayers(): List<StudioLayer> {
        return listOf(
            StudioLayer(
                id = "layer_usb_mirror",
                name = "Mirroring USB",
                type = LayerType.USB_MIRROR,
                isVisible = true,
                isLocked = false,
                x = 0f,
                y = 0f,
                width = 1f,
                height = 1f,
                zIndex = 0,
                keepAspectRatio = true,
                sourceAspect = 16f / 9f
            ),
            StudioLayer(
                id = "layer_host_cam",
                name = "Kamera Host",
                type = LayerType.HOST_CAMERA,
                isVisible = true,
                isLocked = false,
                x = 0.68f,
                y = 0.05f,
                width = 0.28f,
                height = 0.28f,
                zIndex = 1,
                keepAspectRatio = true,
                sourceAspect = 1f
            )
        )
    }

    fun loadLayers(): List<StudioLayer> {
        val jsonString = prefs.getString(KEY_LAYERS, null) ?: return getDefaultLayers()
        return try {
            val jsonArray = JSONArray(jsonString)
            val list = mutableListOf<StudioLayer>()
            for (i in 0 until jsonArray.length()) {
                list.add(StudioLayer.fromJson(jsonArray.getJSONObject(i)))
            }
            if (list.isEmpty()) getDefaultLayers() else list
        } catch (_: Exception) {
            getDefaultLayers()
        }
    }

    fun saveLayers(layers: List<StudioLayer>) {
        val jsonArray = JSONArray()
        for (layer in layers) {
            jsonArray.put(layer.toJson())
        }
        prefs.edit().putString(KEY_LAYERS, jsonArray.toString()).apply()
    }
}
